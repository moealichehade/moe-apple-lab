#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
ARCH="$(uname -m)"
case "$ARCH" in arm64|x86_64) ;; *) echo "Unsupported architecture: $ARCH"; exit 1;; esac
SDK="$(xcrun --sdk macosx --show-sdk-path)"
SWIFT="$(xcrun --find swiftc)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
printf 'Building EducatorBoard for %s...\n' "$ARCH"
"$SWIFT" -parse-as-library -O -target "${ARCH}-apple-macosx13.0" -sdk "$SDK" -framework AppKit -framework UserNotifications EducatorBoard.swift -o "$TMP/EducatorBoard"
APP="$HOME/Applications/EducatorBoard.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
pkill -x EducatorBoard 2>/dev/null || true
cp "$TMP/EducatorBoard" "$APP/Contents/MacOS/EducatorBoard"
chmod +x "$APP/Contents/MacOS/EducatorBoard"
if [[ -f AppIcon.png ]]; then
  cp AppIcon.png "$APP/Contents/Resources/AppIcon.png"
  mkdir -p "$TMP/EducatorBoard.iconset"
  for size in 16 32 128 256 512; do
    sips -z "$size" "$size" AppIcon.png --out "$TMP/EducatorBoard.iconset/icon_${size}x${size}.png" >/dev/null
  done
  for size in 16 32 128 256 512; do
    large=$((size*2)); sips -z "$large" "$large" AppIcon.png --out "$TMP/EducatorBoard.iconset/icon_${size}x${size}@2x.png" >/dev/null
  done
  iconutil -c icns "$TMP/EducatorBoard.iconset" -o "$APP/Contents/Resources/AppIcon.icns"
fi
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>EducatorBoard</string>
<key>CFBundleIdentifier</key><string>com.moeapplelab.educatorboard</string>
<key>CFBundleName</key><string>EducatorBoard</string>
<key>CFBundleDisplayName</key><string>EducatorBoard</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST
codesign --force --deep --sign - "$APP" >/dev/null 2>&1 || true
printf 'Installed: %s\n' "$APP"
open "$APP"
