import AppKit
import Foundation
import UserNotifications

struct BoardItem: Codable, Identifiable {
    var id = UUID()
    var title = ""
    var details = ""
    var category = "Preparation"
    var priority = "Normal"
    var status = "To Do"
    var due: Date? = nil
    var followUp: Date? = nil
    var reminderDate: Date? = nil
    var purpose = "Do this task"
    var sound = true
    var notification = true
    var boardAlert = true
    var recurrence = "Once"
    var lastAlerted: Date? = nil
    var created = Date()
}

final class BoardDatabase {
    var items: [BoardItem] = []
    let categories = ["Preparation", "Lessons", "Assessment", "Communication", "Follow-up", "Other"]
    let statuses = ["To Do", "In Progress", "Waiting", "Done"]
    let center = UNUserNotificationCenter.current()
    var onUpdate: (() -> Void)?
    private var ticker: Timer?
    private var playingSound: NSSound?
    var alertStatus = "Checking notification permission…"
    func testAlerts() {
        playSound()
        let alert = NSAlert()
        alert.messageText = "EducatorBoard · Test Alert"
        alert.informativeText = "On-board alerts are working. A test notification is also scheduled for two seconds from now."
        alert.addButton(withTitle: "OK")
        alert.runModal()
        let content = UNMutableNotificationContent()
        content.title = "EducatorBoard · Test Notification"
        content.body = "Notification delivery test"
        content.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2, repeats: false)
        center.add(UNNotificationRequest(identifier: "educatorboard-test-" + UUID().uuidString, content: content, trigger: trigger)) { [weak self] error in
            if let error = error {
                DispatchQueue.main.async {
                    self?.alertStatus = "Notification test failed: " + error.localizedDescription
                    self?.onUpdate?()
                }
            }
        }
    }
    func playSound() {
        let names=["Glass","Ping","Hero","Pop"]
        for name in names {
            if let tone=NSSound(named: NSSound.Name(name)) {
                playingSound=tone
                tone.volume=1.0
                if tone.play() {return}
            }
        }
        NSSound.beep()
    }
    private var saveURL: URL {
        let d = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support/EducatorBoard", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d.appendingPathComponent("board.json")
    }
    init() {
        if let data = try? Data(contentsOf: saveURL), let loaded = try? JSONDecoder().decode([BoardItem].self, from: data) { items = loaded }
        center.requestAuthorization(options: [.alert, .sound, .badge]) { [weak self] allowed, error in
            DispatchQueue.main.async {
                if let error = error { self?.alertStatus = "Notifications: " + error.localizedDescription }
                else { self?.alertStatus = allowed ? "Notifications authorized" : "Notifications disabled in System Settings" }
                self?.refreshNotifications()
                self?.onUpdate?()
            }
        }
        ticker = Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { [weak self] _ in self?.checkReminders() }
        refreshNotifications()
    }
    func save() {
        if let data = try? JSONEncoder().encode(items) { try? data.write(to: saveURL, options: .atomic) }
        refreshNotifications()
        onUpdate?()
    }
    func upsert(_ item: BoardItem) {
        if let i = items.firstIndex(where: { $0.id == item.id }) { items[i] = item } else { items.insert(item, at: 0) }
        save(); checkReminders()
    }
    func remove(_ id: UUID) { items.removeAll { $0.id == id }; save() }
    func attention(_ item: BoardItem) -> Bool { item.status != "Done" && item.boardAlert && item.reminderDate.map { $0 <= Date() } == true }
    func checkReminders() {
        var changed = false
        for i in items.indices {
            let x = items[i]
            guard x.status != "Done", let date = x.reminderDate, date <= Date() else { continue }
            let interval: Double = x.recurrence == "Daily" ? 86400 : (x.recurrence == "Weekly" ? 604800 : 0)
            let occurrence = interval == 0 ? date : date.addingTimeInterval(floor(Date().timeIntervalSince(date) / interval) * interval)
            if let last = x.lastAlerted, last >= occurrence { continue }
            if x.sound { playSound() }
            items[i].lastAlerted = Date()
            changed = true
        }
        if changed { save() } else if items.contains(where: { attention($0) }) { onUpdate?() }
    }
    func refreshNotifications() {
        // Only remove EducatorBoard's own requests. Never delete another app's notifications.
        center.getPendingNotificationRequests { [weak self] requests in
            guard let self = self else { return }
            let ids = requests.map(\.identifier).filter { $0.hasPrefix("educatorboard-") }
            self.center.removePendingNotificationRequests(withIdentifiers: ids)
            DispatchQueue.main.async { self.scheduleCurrentNotifications() }
        }
    }
    private func scheduleCurrentNotifications() {
        for x in items where x.status != "Done" && x.notification {
            guard let start = x.reminderDate else { continue }
            let step: TimeInterval = x.recurrence == "Daily" ? 86400 : (x.recurrence == "Weekly" ? 604800 : 0)
            let amount = step > 0 ? 8 : 1
            for number in 0..<amount {
                var d = start.addingTimeInterval(Double(number) * step)
                if step > 0 && d <= Date() { d = d.addingTimeInterval(ceil(Date().timeIntervalSince(d) / step) * step) }
                guard d > Date() else { continue }
                let body = UNMutableNotificationContent()
                body.title = x.purpose == "Follow up" ? "EducatorBoard · Follow-up" : "EducatorBoard · Reminder"
                body.body = x.title
                body.sound = x.sound ? .default : nil
                let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: d)
                let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
                let req = UNNotificationRequest(identifier: "educatorboard-\(x.id.uuidString)-\(number)", content: body, trigger: trigger)
                center.add(req) { [weak self] error in
                    if let error = error {
                        DispatchQueue.main.async {
                            self?.alertStatus = "Reminder scheduling failed: " + error.localizedDescription
                            self?.onUpdate?()
                        }
                    }
                }
            }
        }
    }
}

final class EditorWindow: NSWindowController {
    let db: BoardDatabase
    var item: BoardItem
    let titleField = NSTextField(string: "")
    let detailsField = NSTextField(string: "")
    let category = NSPopUpButton()
    let priority = NSPopUpButton()
    let quick = NSPopUpButton()
    let customDate = NSDatePicker()
    let advanced = NSStackView()
    let advancedButton = NSButton(title: "More options ▾", target: nil, action: nil)
    let status = NSPopUpButton()
    let dueToggle = NSButton(checkboxWithTitle: "Set a due date", target: nil, action: nil)
    let followToggle = NSButton(checkboxWithTitle: "Follow up on", target: nil, action: nil)
    let dueDate = NSDatePicker()
    let followDate = NSDatePicker()
    let purpose = NSPopUpButton()
    let repeatPicker = NSPopUpButton()
    let sound = NSButton(checkboxWithTitle: "Sound", target: nil, action: nil)
    let notification = NSButton(checkboxWithTitle: "Mac notification", target: nil, action: nil)
    let board = NSButton(checkboxWithTitle: "On-board alert", target: nil, action: nil)
    private let root = NSStackView()
    private var expanded = false
    init(db: BoardDatabase,item: BoardItem) {
        self.db=db;self.item=item
        let win=NSWindow(contentRect:NSRect(x:0,y:0,width:650,height:640),styleMask:[.titled,.closable,.resizable],backing:.buffered,defer:false)
        win.title=item.title.isEmpty ? "New note" : "Edit note"
        win.minSize=NSSize(width:590,height:570)
        win.center()
        super.init(window:win)
        // Use the window's content view directly. The former scroll document
        // constraints could fail to lay out and leave the entire editor blank.
        root.orientation = .vertical
        root.alignment = .leading
        root.spacing = 12
        root.edgeInsets = NSEdgeInsets(top:18,left:24,bottom:18,right:24)
        root.frame = win.contentView!.bounds
        root.autoresizingMask = [.width,.height]
        win.contentView = root
        let heading=NSTextField(labelWithString:"What needs to be done?")
        heading.font = .systemFont(ofSize:19,weight:.bold)
        root.addArrangedSubview(heading)
        titleField.placeholderString="e.g. Correct exams, prepare lesson, call counselor..."
        titleField.font = .systemFont(ofSize:16)
        addFull(titleField)
        detailsField.placeholderString="Details (optional)"
        addFull(detailsField)
        titleField.stringValue=item.title
        detailsField.stringValue=item.details
        category.addItems(withTitles:db.categories)
        category.selectItem(withTitle:item.category)
        priority.addItems(withTitles:["Normal","High","Urgent"])
        priority.selectItem(withTitle:item.priority)
        let row=NSStackView(views:[label("Category"),category,label("Priority"),priority])
        row.orientation = .horizontal;row.spacing=12
        root.addArrangedSubview(row)
        root.addArrangedSubview(label("Remind me"))
        quick.addItems(withTitles:["No reminder","In 1 hour","Tomorrow at 9 AM","Choose date & time..."])
        quick.selectItem(at:item.reminderDate == nil ? 0 : 3)
        quick.target=self;quick.action=#selector(presetChanged)
        addFull(quick)
        for picker in [customDate,dueDate,followDate] {
            picker.datePickerStyle = .textFieldAndStepper
            picker.datePickerElements = [.yearMonthDay,.hourMinute]
        }
        customDate.dateValue=item.reminderDate ?? Date().addingTimeInterval(3600)
        root.addArrangedSubview(customDate)
        customDate.isHidden=quick.indexOfSelectedItem != 3
        let help=NSTextField(labelWithString:"Your note stays visible until you mark it done.")
        help.font = .systemFont(ofSize:12);help.textColor = .secondaryLabelColor
        root.addArrangedSubview(help)
        advancedButton.target=self;advancedButton.action=#selector(toggleMore)
        root.addArrangedSubview(advancedButton)
        advanced.orientation = .vertical;advanced.alignment = .leading;advanced.spacing = 12
        root.addArrangedSubview(advanced)
        status.addItems(withTitles:db.statuses);status.selectItem(withTitle:item.status)
        let statusRow=NSStackView(views:[label("Status"),status]);statusRow.spacing=12
        advanced.addArrangedSubview(statusRow)
        dueToggle.state=item.due == nil ? .off : .on
        followToggle.state=item.followUp == nil ? .off : .on
        dueDate.dateValue=item.due ?? Date()
        followDate.dateValue=item.followUp ?? Date().addingTimeInterval(86400)
        advanced.addArrangedSubview(dueToggle)
        advanced.addArrangedSubview(dueDate)
        advanced.addArrangedSubview(followToggle)
        advanced.addArrangedSubview(followDate)
        dueToggle.target=self;dueToggle.action=#selector(updateDates)
        followToggle.target=self;followToggle.action=#selector(updateDates)
        purpose.addItems(withTitles:["Do this task","Follow up"]);purpose.selectItem(withTitle:item.purpose)
        repeatPicker.addItems(withTitles:["Once","Daily","Weekly"]);repeatPicker.selectItem(withTitle:item.recurrence)
        let options=NSStackView(views:[label("Purpose"),purpose,label("Repeat"),repeatPicker]);options.spacing=10
        advanced.addArrangedSubview(options)
        advanced.addArrangedSubview(label("Alerts — choose any or all"))
        sound.state=item.sound ? .on : .off
        notification.state=item.notification ? .on : .off
        board.state=item.boardAlert ? .on : .off
        let alerts=NSStackView(views:[sound,notification,board]);alerts.spacing=14
        advanced.addArrangedSubview(alerts)
        let test=NSButton(title:"Test sound",target:self,action:#selector(testSound))
        advanced.addArrangedSubview(test)
        let actions=NSStackView();actions.spacing=12
        let save=NSButton(title:"Save note",target:self,action:#selector(saveNote))
        save.keyEquivalent="\r";save.bezelStyle = .rounded
        actions.addArrangedSubview(save)
        actions.addArrangedSubview(NSButton(title:"Cancel",target:self,action:#selector(cancel)))
        root.addArrangedSubview(actions)
        setExpanded(item.due != nil || item.followUp != nil || item.recurrence != "Once")
        updateDates()
        win.makeFirstResponder(titleField)
    }
    required init?(coder:NSCoder){fatalError("unsupported")}
    private func label(_ text:String)->NSTextField {
        let l=NSTextField(labelWithString:text);l.font = .systemFont(ofSize:12,weight:.medium);return l
    }
    private func addFull(_ v:NSView){
        v.translatesAutoresizingMaskIntoConstraints=false
        root.addArrangedSubview(v)
        v.widthAnchor.constraint(equalTo:root.widthAnchor,constant:-48).isActive=true
    }
    private func setExpanded(_ value:Bool){
        expanded=value
        advanced.isHidden = !value
        advancedButton.title=value ? "Fewer options ▴" : "More options ▾"
        if value { window?.setContentSize(NSSize(width:650,height:830)) }
        else { window?.setContentSize(NSSize(width:650,height:640)) }
    }
    @objc private func toggleMore(){setExpanded(!expanded)}
    @objc private func presetChanged(){customDate.isHidden=quick.indexOfSelectedItem != 3}
    @objc private func updateDates(){dueDate.isHidden=dueToggle.state != .on;followDate.isHidden=followToggle.state != .on}
    @objc private func testSound(){db.playSound()}
    @objc private func cancel(){close()}
    @objc private func saveNote(){
        let name=titleField.stringValue.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !name.isEmpty else {NSSound.beep();return}
        let oldDate=item.reminderDate
        item.title=name;item.details=detailsField.stringValue
        item.category=category.titleOfSelectedItem ?? "Preparation"
        item.priority=priority.titleOfSelectedItem ?? "Normal"
        item.status=status.titleOfSelectedItem ?? "To Do"
        item.due=dueToggle.state == .on ? dueDate.dateValue : nil
        item.followUp=followToggle.state == .on ? followDate.dateValue : nil
        switch quick.indexOfSelectedItem {
          case 1: item.reminderDate=Date().addingTimeInterval(3600)
          case 2:
            var c=Calendar.current.dateComponents([.year,.month,.day],from:Date().addingTimeInterval(86400))
            c.hour=9;c.minute=0;c.second=0
            item.reminderDate=Calendar.current.date(from:c)
          case 3: item.reminderDate=customDate.dateValue
          default: item.reminderDate=nil
        }
        item.purpose=purpose.titleOfSelectedItem ?? "Do this task"
        item.recurrence=repeatPicker.titleOfSelectedItem ?? "Once"
        item.sound=sound.state == .on
        item.notification=notification.state == .on
        item.boardAlert=board.state == .on
        if oldDate != item.reminderDate {item.lastAlerted=nil}
        db.upsert(item);close()
    }
}
final class FlippedEditorView: NSView {
    override var isFlipped:Bool {true}
}

final class PriorityRowView: NSTableRowView {
    var shade:NSColor = .clear
    override func drawBackground(in dirtyRect:NSRect) {
        shade.setFill()
        bounds.fill()
    }
}
final class BoardController: NSWindowController, NSTableViewDataSource, NSTableViewDelegate, NSSearchFieldDelegate {
    let db = BoardDatabase()
    let table = NSTableView()
    let search = NSSearchField()
    let filter = NSPopUpButton()
    let summary = NSTextField(labelWithString: "")
    let attentionLabel = NSTextField(labelWithString: "")
    var visible: [BoardItem] = []
    var editor: EditorWindow?
    private var selectedItemID: UUID?
    private var pulseTimer: Timer?
    private var pulseOn = false
    private var lastAttentionCount = -1
    override init(window: NSWindow?) {
        let w=NSWindow(contentRect:NSRect(x:0,y:0,width:1020,height:710),styleMask:[.titled,.closable,.miniaturizable,.resizable],backing:.buffered,defer:false)
        w.title = "EducatorBoard — Daily Reminder Workspace"
        w.minSize=NSSize(width:800,height:550);w.center()
        super.init(window:w)
        let root=NSStackView();root.orientation = .vertical;root.spacing=14
        root.edgeInsets=NSEdgeInsets(top:20,left:22,bottom:22,right:22)
        w.contentView=root
        let headline=NSTextField(labelWithString:"EducatorBoard")
        headline.font = .systemFont(ofSize:32,weight:.bold)
        root.addArrangedSubview(headline)
        let subtitle=NSTextField(labelWithString:"Capture it. See it. Follow it. Finish it.")
        subtitle.textColor = .secondaryLabelColor
        root.addArrangedSubview(subtitle)
        let toolbar=NSStackView();toolbar.orientation = .horizontal;toolbar.spacing=10
        let add=NSButton(title:"+ Add Note",target:self,action:#selector(addNote))
        let done=NSButton(title:"Mark Done",target:self,action:#selector(markDone))
        let waiting=NSButton(title:"Waiting",target:self,action:#selector(markWaiting))
        let snooze=NSButton(title:"Snooze 1 Hour",target:self,action:#selector(snoozeSelected))
        let edit=NSButton(title:"Edit",target:self,action:#selector(editSelected))
        let delete=NSButton(title:"Delete",target:self,action:#selector(deleteSelected))
        for b in [add,edit,done,waiting,snooze,delete] {toolbar.addArrangedSubview(b)}
        let testAlerts=NSButton(title:"Test Alerts",target:self,action:#selector(runAlertTest))
        toolbar.addArrangedSubview(testAlerts)
        root.addArrangedSubview(toolbar)
        summary.font = .systemFont(ofSize:14,weight:.medium)
        root.addArrangedSubview(summary)
        attentionLabel.font = .systemFont(ofSize:13,weight:.semibold)
        attentionLabel.textColor = .systemRed
        root.addArrangedSubview(attentionLabel)
        let attentionButton = NSButton(title:"Show Attention Needed →", target:self, action:#selector(showAttention))
        attentionButton.bezelStyle = .inline
        root.addArrangedSubview(attentionButton)
        let controls=NSStackView();controls.orientation = .horizontal;controls.spacing=12
        search.placeholderString="Search tasks and notes"; search.delegate=self
        search.widthAnchor.constraint(equalToConstant:420).isActive=true
        filter.addItems(withTitles:["Open","Attention Needed","To Do","In Progress","Waiting","Done","All"])
        filter.target=self;filter.action=#selector(refresh)
        controls.addArrangedSubview(search);controls.addArrangedSubview(filter)
        root.addArrangedSubview(controls)
        let scroll=NSScrollView();scroll.hasVerticalScroller=true;scroll.borderType = .bezelBorder
        table.headerView = NSTableHeaderView()
        let cols=[("Task",380.0),("Category",120.0),("Priority",95.0),("Status",120.0),("Reminder",180.0)]
        for (id,width) in cols {
            let c=NSTableColumn(identifier:NSUserInterfaceItemIdentifier(id))
            c.title=id;c.width=width;table.addTableColumn(c)
        }
        table.rowHeight=38;table.usesAlternatingRowBackgroundColors=false
        table.delegate=self;table.dataSource=self;table.target=self;table.doubleAction=#selector(editSelected)
        scroll.documentView=table
        root.addArrangedSubview(scroll)
        scroll.heightAnchor.constraint(greaterThanOrEqualToConstant:300).isActive=true
        let foot=NSTextField(labelWithString:"Private local board · sound requires app running · macOS notifications require permission")
        foot.textColor = .secondaryLabelColor;foot.font = .systemFont(ofSize:12)
        root.addArrangedSubview(foot)
        let alertFeedback=NSTextField(labelWithString:"Use Test Alerts to verify sound, notification, and in-app alert.")
        alertFeedback.font = .systemFont(ofSize:12)
        alertFeedback.textColor = .secondaryLabelColor
        alertFeedback.identifier=NSUserInterfaceItemIdentifier("alertFeedback")
        root.addArrangedSubview(alertFeedback)
        let quit=NSButton(title:"Quit EducatorBoard",target:self,action:#selector(quit))
        root.addArrangedSubview(quit)
        db.onUpdate = { [weak self] in self?.refresh() }
        pulseTimer = Timer.scheduledTimer(withTimeInterval: 0.65, repeats: true) { [weak self] _ in
            self?.pulseAttention()
        }
        refresh()

    }
    required init?(coder:NSCoder) { fatalError("init(coder:) unavailable") }
    func tableViewSelectionDidChange(_ notification: Notification) {
        let index = table.selectedRow
        if index >= 0 && index < visible.count { selectedItemID = visible[index].id }
    }
    private func pulseAttention() {
        guard db.items.contains(where: { db.attention($0) }) else {
            attentionLabel.textColor = .secondaryLabelColor
            attentionLabel.alphaValue = 1
            pulseOn = false
            return
        }
        pulseOn.toggle()
        attentionLabel.textColor = pulseOn ? .systemRed : .systemOrange
        attentionLabel.alphaValue = pulseOn ? 1.0 : 0.48
        // Only redraw the highlighted rows: do not reload the table or lose selection.
        table.enumerateAvailableRowViews { view, index in
            if index < self.visible.count && self.db.attention(self.visible[index]) {
                view.needsDisplay = true
            }
        }
    }
    @objc private func showAttention() {
        filter.selectItem(withTitle:"Attention Needed")
        search.stringValue=""
        refresh()
        window?.makeKeyAndOrderFront(nil)
    }

    func numberOfRows(in tableView:NSTableView)->Int { visible.count }
    func tableView(_ tableView:NSTableView,rowViewForRow row:Int)->NSTableRowView? {
        guard row < visible.count else {return nil}
        let item=visible[row]
        let view=PriorityRowView()
        if item.status == "Done" {view.shade=NSColor.systemGray.withAlphaComponent(0.09)}
        else if db.attention(item) {view.shade=NSColor.systemRed.withAlphaComponent(0.19)}
        else if item.priority == "Urgent" {view.shade=NSColor.systemRed.withAlphaComponent(0.13)}
        else if item.priority == "High" {view.shade=NSColor.systemOrange.withAlphaComponent(0.15)}
        else {view.shade=NSColor.systemTeal.withAlphaComponent(0.10)}
        return view
    }
    func tableView(_ tableView:NSTableView,viewFor tableColumn:NSTableColumn?,row:Int)->NSView? {
        guard row < visible.count else {return nil}
        let item=visible[row];let id=tableColumn?.identifier.rawValue ?? "Task"
        let cell=NSTableCellView()
        let label=NSTextField(labelWithString:"")
        label.lineBreakMode = .byTruncatingTail
        switch id {
        case "Task":label.stringValue = (db.attention(item) ? "⚑  " : "")+item.title
        case "Category":label.stringValue=item.category
        case "Priority":label.stringValue=item.priority
        case "Status":label.stringValue=item.status
        case "Reminder":label.stringValue=item.reminderDate?.formatted(date:.abbreviated,time:.shortened) ?? "—"
        default:break
        }
        if db.attention(item) { label.textColor = .systemRed }
        if id == "Priority" { label.font = .systemFont(ofSize:12,weight:.bold) }
        label.translatesAutoresizingMaskIntoConstraints=false;cell.addSubview(label)
        NSLayoutConstraint.activate([label.leadingAnchor.constraint(equalTo:cell.leadingAnchor,constant:8),label.trailingAnchor.constraint(equalTo:cell.trailingAnchor,constant:-4),label.centerYAnchor.constraint(equalTo:cell.centerYAnchor)])
        return cell
    }
    func controlTextDidChange(_ obj:Notification) {refresh()}
    @objc func refresh() {
        // Preserve which note the user chose, even as due-state text updates.
        if table.selectedRow >= 0 && table.selectedRow < visible.count {
            selectedItemID = visible[table.selectedRow].id
        }
        let q=search.stringValue
        let mode=filter.titleOfSelectedItem ?? "Open"
        visible=db.items.filter { item in
            let matches=q.isEmpty || (item.title+" "+item.details+" "+item.category).localizedCaseInsensitiveContains(q)
            let selected=mode == "All" || (mode == "Open" && item.status != "Done") || (mode == "Attention Needed" && db.attention(item)) || mode == item.status
            return matches && selected
        }
        let open=db.items.filter{$0.status != "Done"}.count
        let wait=db.items.filter{$0.status == "Waiting"}.count
        let att=db.items.filter{db.attention($0)}.count
        summary.stringValue="Open: \(open)      Waiting: \(wait)      Attention Needed: \(att)"
        attentionLabel.stringValue=att > 0 ? "\(att) reminder(s) need attention — open Attention Needed to follow up." : "No reminders need attention right now."
        if let label = (window?.contentView as? NSStackView)?.arrangedSubviews.first(where: { $0.identifier?.rawValue == "alertFeedback" }) as? NSTextField { label.stringValue=db.alertStatus }
        // Rebuild table only for changes in its contents, not just pulse ticks.
        table.reloadData()
        if let id=selectedItemID, let position=visible.firstIndex(where:{$0.id == id}) {
            table.selectRowIndexes(IndexSet(integer:position), byExtendingSelection:false)
        }
    }
    @objc private func runAlertTest(){db.testAlerts()}
    private func selected()->BoardItem? {
        let row=table.selectedRow
        if row >= 0 && row < visible.count {return visible[row]}
        if let id=selectedItemID { return db.items.first(where:{$0.id == id}) }
        return nil
    }
    @objc private func addNote(){editor=EditorWindow(db:db,item:BoardItem());editor?.showWindow(nil);editor?.window?.makeKeyAndOrderFront(nil);NSApp.activate(ignoringOtherApps:true)}
    @objc private func editSelected(){
        guard let item=selected() else {
            let info=NSAlert();info.messageText="Select a note to edit";info.informativeText="Click a row in the board first, then choose Edit. You can also double-click a note.";info.runModal();return
        }
        editor=EditorWindow(db:db,item:item)
        editor?.showWindow(nil)
        editor?.window?.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps:true)
    }
    @objc private func markDone(){guard var x=selected() else {return};x.status="Done";db.upsert(x)}
    @objc private func markWaiting(){guard var x=selected() else {return};x.status="Waiting";db.upsert(x)}
    @objc private func snoozeSelected(){guard var x=selected(), x.reminderDate != nil else {return};x.reminderDate=Date().addingTimeInterval(3600);x.lastAlerted=nil;db.upsert(x)}
    @objc private func deleteSelected(){guard let item=selected() else {return};let alert=NSAlert();alert.messageText="Delete note?";alert.informativeText=item.title;alert.addButton(withTitle:"Delete");alert.addButton(withTitle:"Cancel");if alert.runModal() == NSApplication.ModalResponse.alertFirstButtonReturn {db.remove(item.id)}}
    @objc private func quit(){NSApp.terminate(nil)}
}

final class ApplicationMain: NSObject, NSApplicationDelegate, UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .list, .sound])
    }
    var board: BoardController?
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        UNUserNotificationCenter.current().delegate=self
        board=BoardController(window:nil)
        board?.showWindow(nil)
        NSApp.activate(ignoringOtherApps:true)
        let menu=NSMenu()
        let appMenu=NSMenu();appMenu.addItem(NSMenuItem(title:"Quit EducatorBoard",action:#selector(NSApplication.terminate(_:)),keyEquivalent:"q"))
        let appItem=NSMenuItem(title:"EducatorBoard",action:nil,keyEquivalent:"")
        appItem.submenu=appMenu;menu.addItem(appItem);NSApp.mainMenu=menu
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender:NSApplication)->Bool {false}
}
@main struct StartEducatorBoard {
    static func main() {
        let app=NSApplication.shared
        let delegate=ApplicationMain()
        app.delegate=delegate
        app.run()
    }
}
