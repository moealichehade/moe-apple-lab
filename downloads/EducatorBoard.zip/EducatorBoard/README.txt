EducatorBoard Add Note Fix

The New Note and Edit Note windows now use a direct native AppKit content layout instead of the scroll document constraints that left the window blank.

Install:
cd ~/Downloads
unzip -o EducatorBoard_AddNote_Fixed.zip
cd EducatorBoard
bash Install.command

Existing notes remain in their local storage.
