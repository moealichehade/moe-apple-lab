Monthly Overview  
****Monthly Overview****  
#month-plan  
  
****Outcomes****  
Outcome 1 — [What should be different by month end?]  
Outcome 2 — [What else matters this month?]  
  
****Deadlines and commitments****  
[Date] — [Commitment]  
  
****Later****  
[Ideas or commitments for a later month]  
  
****Next actions****  
Add one concrete next step per outcome to Coming Up. Move the steps you can take this week to Weekly Actions.  
