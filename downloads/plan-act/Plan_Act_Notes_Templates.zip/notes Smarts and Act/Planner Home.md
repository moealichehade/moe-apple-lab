Planner Home  
****Planner Home****  
  
****Monthly Overview****  
Review goals and deadlines before choosing weekly actions.  
Monthly Overview  
  
****Weekly Review****  
Sort what you captured and choose what matters this week.  
Weekly Review  
  
****Project Brief****  
Use this template when starting a project.  
Project Brief  
  
****Smart Reminders Planner Launch****  
Open the current project to review the template links and next step.  
Smart Reminders Planner Launch  
