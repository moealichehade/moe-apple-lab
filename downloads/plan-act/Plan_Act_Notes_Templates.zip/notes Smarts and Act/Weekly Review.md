Weekly Review  
****Weekly Review****  
#weekly-review  
  
****Week of****  
[Date]  
  
****Look back****  
What moved forward?  
What is still waiting, and who needs a follow-up?  
  
****Look ahead****  
Which deadlines are coming up?  
Which one to three outcomes matter most?  
  
****Update Reminders****  
Sort Quick Capture. Move doable actions to Weekly Actions and key commitments to Weekly Focus. Give each action a due date when you choose its day.  
