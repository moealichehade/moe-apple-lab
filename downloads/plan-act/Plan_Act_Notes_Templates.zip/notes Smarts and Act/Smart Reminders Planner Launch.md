Smart Reminders Planner Launch  
****Smart Reminders Planner Launch****  
#active #this-week  
  
****Outcome****  
Give people a working Apple Reminders planner they can add to their device.  
  
****Resources****  
Add the shared template links and finished setup screenshots here.  
  
****Next action****  
Test the Daily Focus template link and record what it installs.  
