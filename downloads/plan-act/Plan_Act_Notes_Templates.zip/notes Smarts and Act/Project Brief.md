Project Brief  
****Project Brief****  
#project  
  
****Project and outcome****  
[Project name]  
[How will I know the project is finished?]  
  
****Resources****  
[Links, related notes, or files]  
  
****Decisions and status****  
[What was decided?]  
[What is moving or blocked?]  
  
****Next action****  
[A concrete action and its due date, if known]  
Track the steps in your project list created from the Project Tracker template. From this note, use Share → Reminders to create an action with a link back to the note.  
