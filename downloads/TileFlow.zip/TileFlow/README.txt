TileFlow — window manager (v0.3)

Install: bash Install.command
App: ~/Applications/TileFlow.app

TileFlow starts without moving windows. It will not rearrange windows until you choose Arrange All Windows.
Menu: Check Accessibility Permission; Request Access; Arrange; Reset; Pause; Quit.
Hotkeys: Ctrl+Option+arrows to navigate, Ctrl+Option+Shift+arrows to reorder, Ctrl+Option+R to change width, Ctrl+Option+Z to restore.

Reset and Quit attempt to restore original positions and sizes of still-open windows. Closed windows cannot be restored. A crashed or force-quit app cannot guarantee restoring positions.

Accessibility: System Settings > Privacy & Security > Accessibility, add ~/Applications/TileFlow.app, enable and relaunch TileFlow.
Hotkeys are registered through macOS Carbon and may fail if reserved by another app or by macOS.

Tested by creator on an Apple Silicon Mac. The app requires Accessibility permission.

TileFlow Menu Refresh: grouped actions and SF Symbols; window manager and shortcuts unchanged.
Note: Rebuilding ad-hoc signed macOS apps can require Accessibility reapproval.
