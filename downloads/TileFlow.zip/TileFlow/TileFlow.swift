import AppKit
import ApplicationServices
import Carbon.HIToolbox

struct ManagedWindow {
    let element: AXUIElement
    let pid: pid_t
    let identity: String
    let initial: CGRect
}

final class FlowEngine {
    var active = false
    var windows: [ManagedWindow] = []
    var current = 0
    var widthFraction: CGFloat = 0.68
    var gap: CGFloat = 12
    var report: (String) -> Void = { _ in }
    private var originals: [String: ManagedWindow] = [:]

    var hasPermission: Bool { AXIsProcessTrusted() }
    func promptPermission() {
        let options = ["AXTrustedCheckOptionPrompt": true] as CFDictionary
        _ = AXIsProcessTrustedWithOptions(options)
    }
    func attribute<T>(_ e: AXUIElement, _ name: String) -> T? {
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(e, name as CFString, &value) == .success else { return nil }
        return value as? T
    }
    func frame(_ e: AXUIElement) -> CGRect? {
        var pos: CFTypeRef?; var size: CFTypeRef?
        guard AXUIElementCopyAttributeValue(e, kAXPositionAttribute as CFString, &pos) == .success,
              AXUIElementCopyAttributeValue(e, kAXSizeAttribute as CFString, &size) == .success,
              let pp = pos, let ss = size,
              CFGetTypeID(pp) == AXValueGetTypeID(), CFGetTypeID(ss) == AXValueGetTypeID() else { return nil }
        var point = CGPoint.zero; var dims = CGSize.zero
        guard AXValueGetValue(pp as! AXValue, .cgPoint, &point), AXValueGetValue(ss as! AXValue, .cgSize, &dims) else { return nil }
        return CGRect(origin: point, size: dims)
    }
    @discardableResult func position(_ e: AXUIElement, at target: CGRect) -> Bool {
        var size = target.size; var origin = target.origin
        guard let s = AXValueCreate(.cgSize, &size), let p = AXValueCreate(.cgPoint, &origin) else { return false }
        let sr = AXUIElementSetAttributeValue(e, kAXSizeAttribute as CFString, s)
        let pr = AXUIElementSetAttributeValue(e, kAXPositionAttribute as CFString, p)
        return sr == .success && pr == .success
    }
    @discardableResult func discover() -> Int {
        guard hasPermission else { report("Accessibility not recognized"); return 0 }
        var fresh: [ManagedWindow] = []
        for app in NSWorkspace.shared.runningApplications where app.activationPolicy == .regular && !app.isTerminated && app.processIdentifier != ProcessInfo.processInfo.processIdentifier {
            let parent = AXUIElementCreateApplication(app.processIdentifier)
            guard let items: [AXUIElement] = attribute(parent, kAXWindowsAttribute) else { continue }
            for win in items {
                let role: String = attribute(win, kAXRoleAttribute) ?? ""
                let minimized: Bool = attribute(win, kAXMinimizedAttribute) ?? false
                let fullscreen: Bool = attribute(win, "AXFullScreen") ?? false
                guard role == (kAXWindowRole as String), !minimized, !fullscreen,
                      let rect = frame(win), rect.width > 180, rect.height > 110 else { continue }
                let key = "\(app.processIdentifier):\(CFHash(win))"
                let rec = ManagedWindow(element: win, pid: app.processIdentifier, identity: key, initial: rect)
                fresh.append(rec)
                if originals[key] == nil { originals[key] = rec }
            }
        }
        let order = windows.map(\.identity)
        fresh.sort { a, b in
            let i = order.firstIndex(of: a.identity) ?? Int.max
            let j = order.firstIndex(of: b.identity) ?? Int.max
            return i == j ? a.identity < b.identity : i < j
        }
        windows = fresh
        current = max(0, min(current, windows.count - 1))
        report("\(windows.count) windows found")
        return windows.count
    }
    func arrange() {
        guard hasPermission else { report("Accessibility required — use Permission Check"); return }
        guard discover() > 0 else { report("No movable windows found"); return }
        active = true
        layout()
    }
    func layout() {
        guard active, !windows.isEmpty else { return }
        let bounds = (NSScreen.main ?? NSScreen.screens.first)?.visibleFrame ?? CGRect(x: 0, y: 0, width: 1200, height: 800)
        let globalTop = NSScreen.screens.map { $0.frame.maxY }.max() ?? bounds.maxY
        let width = max(320, bounds.width * widthFraction)
        let column = width + gap
        var applied = 0
        for (index, win) in windows.enumerated() {
            let x = bounds.midX - width / 2 + CGFloat(index - current) * column
            let y = globalTop - bounds.maxY + gap
            if position(win.element, at: CGRect(x: x, y: y, width: width, height: max(220, bounds.height - 2 * gap))) { applied += 1 }
        }
        report("Arranged \(applied)/\(windows.count) windows")
    }
    func navigate(_ by: Int) {
        guard active, !windows.isEmpty else { report("Arrange windows first"); return }
        current = (current + by + windows.count) % windows.count
        layout()
        let win = windows[current]
        if let app = NSRunningApplication(processIdentifier: win.pid) { app.activate(options: []) }
        _ = AXUIElementPerformAction(win.element, kAXRaiseAction as CFString)
    }
    func swap(_ by: Int) {
        guard active, windows.count > 1 else { return }
        let target = current + by
        guard windows.indices.contains(target) else { return }
        windows.swapAt(current, target)
        current = target
        layout()
    }
    func resize() {
        guard active else { report("Arrange windows first"); return }
        let widths: [CGFloat] = [0.50, 0.68, 0.85, 1.0]
        let nearest = widths.enumerated().min { abs($0.element - widthFraction) < abs($1.element - widthFraction) }?.offset ?? 0
        widthFraction = widths[(nearest + 1) % widths.count]
        layout()
    }
    func restore() {
        active = false
        var restored = 0
        for original in originals.values {
            if frame(original.element) != nil && position(original.element, at: original.initial) { restored += 1 }
        }
        originals.removeAll()
        windows.removeAll(); current = 0
        report("Restored \(restored) windows")
    }
}

final class TileFlowController: NSObject, NSApplicationDelegate {
    private let engine = FlowEngine()
    private var status: NSStatusItem!
    private let menu = NSMenu()
    private let permissionLine = NSMenuItem(title: "Checking Accessibility…", action: nil, keyEquivalent: "")
    private let stateLine = NSMenuItem(title: "Ready", action: nil, keyEquivalent: "")
    private var hotkeys: [EventHotKeyRef?] = []
    private var hotkeyHandler: EventHandlerRef?
    private var permissionPoll: Timer?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        status = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        status.button?.title = "▥ TileFlow"
        menu.autoenablesItems = false
        permissionLine.isEnabled = false
        stateLine.isEnabled = false
        menu.addItem(permissionLine)
        menu.addItem(stateLine)
        menu.addItem(.separator())

        add("Tile All Windows", #selector(arrange), icon: "rectangle.3.group")
        add("Restore Original Layout  ⌃⌥Z", #selector(reset), icon: "arrow.uturn.backward")
        menu.addItem(.separator())

        section("WINDOW NAVIGATION")
        add("Next Window  ⌃⌥→", #selector(next), icon: "arrow.right")
        add("Previous Window  ⌃⌥←", #selector(previous), icon: "arrow.left")
        menu.addItem(.separator())

        section("WINDOW POSITION")
        add("Move Window Left  ⌃⌥⇧←", #selector(moveLeft), icon: "arrow.left.to.line")
        add("Move Window Right  ⌃⌥⇧→", #selector(moveRight), icon: "arrow.right.to.line")
        add("Cycle Window Width  ⌃⌥R", #selector(resize), icon: "arrow.left.and.right.righttriangle.left.righttriangle.right")
        menu.addItem(.separator())

        let tools = NSMenu(title: "Tools")
        let toolsItem = NSMenuItem(title: "Tools", action: nil, keyEquivalent: "")
        toolsItem.image = NSImage(systemSymbolName: "slider.horizontal.3", accessibilityDescription: nil)
        addTo(tools, "Pause & Restore Windows", #selector(reset), icon: "pause.circle")
        tools.addItem(.separator())
        addTo(tools, "Check Accessibility", #selector(checkPermission), icon: "checkmark.shield")
        addTo(tools, "Open Accessibility Settings…", #selector(requestPermission), icon: "gearshape")
        menu.setSubmenu(tools, for: toolsItem)
        menu.addItem(toolsItem)

        let help = NSMenu(title: "Help")
        let helpItem = NSMenuItem(title: "Help", action: nil, keyEquivalent: "")
        helpItem.image = NSImage(systemSymbolName: "questionmark.circle", accessibilityDescription: nil)
        addTo(help, "About & Diagnostics", #selector(about), icon: "info.circle")
        menu.setSubmenu(help, for: helpItem)
        menu.addItem(helpItem)
        menu.addItem(.separator())
        add("Quit & Restore Windows", #selector(quit), icon: "power")
        status.menu = menu
        engine.report = { [weak self] message in self?.stateLine.title = message }
        refreshPermission()
        permissionPoll = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) { [weak self] _ in self?.refreshPermission() }
        installHotkeys()
    }
    private func add(_ title: String, _ action: Selector, icon: String) {
        addTo(menu, title, action, icon: icon)
    }
    private func addTo(_ targetMenu: NSMenu, _ title: String, _ action: Selector, icon: String) {
        let item = NSMenuItem(title: title, action: action, keyEquivalent: "")
        item.target = self
        item.image = NSImage(systemSymbolName: icon, accessibilityDescription: title)
        targetMenu.addItem(item)
    }
    private func section(_ title: String) {
        let item = NSMenuItem(title: title, action: nil, keyEquivalent: "")
        item.isEnabled = false
        menu.addItem(item)
    }
    private func refreshPermission() {
        permissionLine.title = engine.hasPermission ? "Accessibility enabled ✓" : "Accessibility permission needed"
    }
    @objc private func checkPermission() {
        refreshPermission()
        let alert = NSAlert(); alert.messageText = engine.hasPermission ? "Accessibility is working" : "Accessibility is not recognized"
        alert.informativeText = engine.hasPermission ? "TileFlow can now arrange application windows. Choose Arrange All Windows." : "Open System Settings → Privacy & Security → Accessibility and add the installed TileFlow app. Then quit and reopen TileFlow. The app will recheck permission automatically."
        alert.addButton(withTitle: "OK"); alert.runModal()
    }
    @objc private func requestPermission() { engine.promptPermission(); refreshPermission() }
    @objc private func arrange() { engine.arrange(); refreshPermission() }
    @objc private func reset() { engine.restore() }
    @objc private func next() { engine.navigate(1) }
    @objc private func previous() { engine.navigate(-1) }
    @objc private func moveRight() { engine.swap(1) }
    @objc private func moveLeft() { engine.swap(-1) }
    @objc private func resize() { engine.resize() }
    @objc private func quit() { engine.restore(); NSApp.terminate(nil) }
    func applicationWillTerminate(_ notification: Notification) { engine.restore() }
    @objc private func about() {
        let alert = NSAlert(); alert.messageText = "TileFlow — Clean Test Build"
        alert.informativeText = "Accessibility: \(engine.hasPermission ? "Allowed" : "Not recognized")\nApp location: \(Bundle.main.bundlePath)\n\nShortcuts:\n⌃⌥← / →  Navigate\n⌃⌥⇧← / →  Move\n⌃⌥R  Width\n⌃⌥Z  Restore all windows\n\nTileFlow only moves windows when you choose a tiling action. Reset, Pause, and Quit restore windows that remain open."
        alert.addButton(withTitle: "OK"); alert.runModal()
    }
    private func installHotkeys() {
        var eventType = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
        let callback: EventHandlerUPP = { _, event, pointer in
            guard let event, let pointer else { return OSStatus(eventNotHandledErr) }
            var key = EventHotKeyID()
            guard GetEventParameter(event, EventParamName(kEventParamDirectObject), EventParamType(typeEventHotKeyID), nil, MemoryLayout<EventHotKeyID>.size, nil, &key) == noErr else { return OSStatus(eventNotHandledErr) }
            let controller = Unmanaged<TileFlowController>.fromOpaque(pointer).takeUnretainedValue()
            DispatchQueue.main.async { controller.handle(Int(key.id)) }
            return noErr
        }
        let installed = InstallEventHandler(GetApplicationEventTarget(), callback, 1, &eventType, Unmanaged.passUnretained(self).toOpaque(), &hotkeyHandler)
        guard installed == noErr else { stateLine.title = "Hotkeys unavailable; use the menu"; return }
        let mods = UInt32(controlKey | optionKey)
        let mappings: [(UInt32, UInt32)] = [(UInt32(kVK_LeftArrow), mods), (UInt32(kVK_RightArrow), mods), (UInt32(kVK_LeftArrow), mods | UInt32(shiftKey)), (UInt32(kVK_RightArrow), mods | UInt32(shiftKey)), (UInt32(kVK_ANSI_R), mods), (UInt32(kVK_ANSI_Z), mods)]
        var failures = 0
        for (i, mapping) in mappings.enumerated() {
            let identifier = EventHotKeyID(signature: 0x54464C57, id: UInt32(i + 1))
            var reference: EventHotKeyRef?
            let result = RegisterEventHotKey(mapping.0, mapping.1, identifier, GetApplicationEventTarget(), 0, &reference)
            if result == noErr { hotkeys.append(reference) } else { failures += 1 }
        }
        if failures > 0 { stateLine.title = "\(failures) shortcuts conflict with macOS; use menu" }
    }
    private func handle(_ id: Int) {
        switch id {
        case 1: previous()
        case 2: next()
        case 3: moveLeft()
        case 4: moveRight()
        case 5: resize()
        case 6: reset()
        default: break
        }
    }
}

@main struct TileFlowApplication {
    static func main() {
        let app = NSApplication.shared
        let controller = TileFlowController()
        app.delegate = controller
        app.run()
    }
}
