#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
SWIFT="$(xcrun -f swiftc)"
SDK="$(xcrun --sdk macosx --show-sdk-path)"
ARCH="$(uname -m)"
DEST="$HOME/Applications/TileFlow.app"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
printf 'Building TileFlow Clean for %s...\n' "$ARCH"
"$SWIFT" -parse-as-library -O -target "${ARCH}-apple-macosx13.0" -sdk "$SDK" -framework AppKit -framework ApplicationServices -framework Carbon TileFlow.swift -o "$TMP/TileFlow"
pkill -x TileFlow >/dev/null 2>&1 || true
sleep 1
mkdir -p "$HOME/Applications"
rm -rf "$DEST"
mkdir -p "$DEST/Contents/MacOS" "$DEST/Contents/Resources"
cp "$TMP/TileFlow" "$DEST/Contents/MacOS/TileFlow"
chmod 755 "$DEST/Contents/MacOS/TileFlow"
cat > "$DEST/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>com.moeapplelab.tileflow</string>
<key>CFBundleName</key><string>TileFlow</string>
<key>CFBundleExecutable</key><string>TileFlow</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>LSUIElement</key><true/>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST
if [ -f AppIcon.png ]; then
 mkdir "$TMP/AppIcon.iconset"
 for n in 16 32 128 256 512; do sips -z "$n" "$n" AppIcon.png --out "$TMP/AppIcon.iconset/icon_${n}x${n}.png" >/dev/null; done
 for n in 16 32 128 256; do d=$((n*2)); sips -z "$d" "$d" AppIcon.png --out "$TMP/AppIcon.iconset/icon_${n}x${n}@2x.png" >/dev/null; done
 iconutil -c icns "$TMP/AppIcon.iconset" -o "$DEST/Contents/Resources/AppIcon.icns"
fi
# Stable bundle identifier and application path. A local ad-hoc signature is not
# a Developer ID signature; permission may need approval again after rebuilding.
codesign --force --sign - --identifier com.moeapplelab.tileflow "$DEST"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true
printf '\nINSTALLED: %s\n' "$DEST"
printf 'NEXT: Open macOS Accessibility Settings and grant access to THIS app.\n'
printf 'TileFlow starts idle. Use its menu icon to verify permission and Arrange.\n'
open "$DEST"
